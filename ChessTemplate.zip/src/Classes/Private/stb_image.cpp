#define STB_IMAGE_IMPLEMENTATION
#include "../Public/stb_image.h"

