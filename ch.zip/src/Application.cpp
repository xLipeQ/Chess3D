#include "Classes/Public/Renderer.h"
#include <GL/glew.h>
#include <GLFW/glfw3.h>
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>

#include "Classes/Public/Model.h"
#include "Classes/Public/Shader.h"
#include "Classes/Public/Camera.h"

int main()
{
	// Initialize GLFW
	GLFWwindow* window;

	if(!glfwInit())
		return -1;

	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	window = glfwCreateWindow(Camera::Width, Camera::Height, "YoutubeOpenGL", NULL, NULL);
	if (!window)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}

	glfwMakeContextCurrent(window);

	glfwSwapInterval(1);

	if (glewInit() != GLEW_OK)
		return -2;

	std::cout << glGetString(GL_VERSION);

	float positions[] =
	{//  COORDINATES     /    COLORS	/	/ TexCoord	/
		-0.5f, -0.5f,   0.0f, 0.0f, 0.83f,   0.70f, 0.44f, // 0
		0.5f, -0.5f,	1.0f, 0.0f, 0.83f,   0.70f, 0.44f, // 1
		0.5f, 0.5f,     1.0f, 1.0f, 0.83f,   0.70f, 0.44f, // 2
		-0.5f, 0.5f,    0.0f, 1.0f, 0.83f,   0.70f, 0.44f, // 3
	};

	uint indices[] =
	{
		0, 1, 2,
		2, 3, 0
	};

	// Vertices coordinates
	float positions3D[] =
	{ //     COORDINATES     /        COLORS      /   TexCoord  //
		-0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f,	0.0f, 0.0f,
		-0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	5.0f, 0.0f,
		 0.5f, 0.0f, -0.5f,     0.83f, 0.70f, 0.44f,	0.0f, 0.0f,
		 0.5f, 0.0f,  0.5f,     0.83f, 0.70f, 0.44f,	5.0f, 0.0f,
		 0.0f, 0.8f,  0.0f,     0.92f, 0.86f, 0.76f,	2.5f, 2.5f
	};

	uint indices3D[] =
	{
		0, 1, 2,
		0, 2, 3,
		0, 1, 4,
		1, 2, 4,
		2, 3, 4,
		3, 0, 4
	};

	VertexArray* VA = new VertexArray();
	VertexBufferLayout* VBL = new VertexBufferLayout();
	VertexBuffer* VB = new VertexBuffer(positions3D, 5 * 8 * sizeof(float));

	// positions
	VBL->Push<float>(3);
	// colors
	VBL->Push<float>(3);
	// texcords
	VBL->Push<float>(2);
	VA->AddBuffer(*VB, *VBL);

	IndexBuffer* IB = new IndexBuffer(indices3D, sizeof(indices3D) / sizeof(uint));

	Shader shader("res/shaders/Basic.shader");
	shader.Bind();

	Texture* texture = new Texture("res/textures/pawn/pawn.png");
	texture->Bind();
	shader.SetUniform1i("u_Texture", 0);

	VA->UnBind();
	shader.UnBind();
	VB->UnBind();
	IB->UnBind();

	Model* model = new Model("res/textures/pawn/pawn.obj", "res/textures/pawn/pawn.png");
	Shader modelShader("res/shaders/Model.shader");
	modelShader.Bind();
	modelShader.SetUniform1i("u_Texture", 0);

	Renderer renderer;
	Camera* camera = new Camera(glm::vec3(0.f, 0.f, 2.f));
	Camera::SetScrollInput(window);
	Camera::SetWorkingCamera(camera);
	
	glEnable(GL_DEPTH_TEST);
	glm::mat4 temp(1.f);
	modelShader.SetUniformMatrix4fv("u_Model", glm::value_ptr(model->m_ModelMatrix));
	//modelShader.SetUniformMatrix4fv("u_Model", glm::value_ptr(temp));

	// Main while loop
	while (!glfwWindowShouldClose(window))
	{
		renderer.Clear();

		/*shader.Bind();

		VA->Bind();
		IB->Bind();*/
		modelShader.Bind();

		// Handles camera inputs
		camera->Inputs(window);
		// Updates and exports the camera matrix to the Vertex Shader
		camera->Matrix(45.0f, 0.1f, 100.0f, modelShader, "u_camMatrix");
		renderer.Draw(*model, modelShader);

		//shader.Bind();
		//camera->Matrix(45.0f, 0.1f, 100.0f, shader, "u_camMatrix");

		//renderer.Draw(*VA, *IB, shader);
		
		// Swap the back buffer with the front buffer
		glfwSwapBuffers(window);
		// Take care of all GLFW events
		glfwPollEvents();
	}

	delete(IB);
	delete(VB);
	delete(VA);
	//delete(texture);
	delete(camera);
	delete(model);

	// Delete window before ending the program
	glfwDestroyWindow(window);


	// Terminate GLFW before ending the program
	glfwTerminate();
	return 0;
}