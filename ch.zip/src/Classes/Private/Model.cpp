#include "../Public/Model.h"
#include <fstream>
#include <sstream>
#include <cstring>
#include <cstdlib>
#include <iostream>
#include <glm/fwd.hpp>
#include <glm/gtc/matrix_transform.hpp>

Model::Model(const std::string& pathobj, const std::string& pathpng)
{
	m_VA = new VertexArray();

	auto data = ReadObj(pathobj);
	
	m_VB = new VertexBuffer(data.data(), data.size());
	
	m_VBL = new VertexBufferLayout();

	// positions
	m_VBL->Push<float>(3);
	// texture
	m_VBL->Push<float>(2);
	// normals
	m_VBL->Push<float>(3);

	m_VA->AddBuffer(*m_VB, *m_VBL);

	m_Texture = new Texture(pathpng);

	std::vector<uint> indicies;
	for (uint i = 0; i < data.size() / 8; i++)
		indicies.push_back(i);

	m_IB = new IndexBuffer(indicies.data(), indicies.size());

	m_ModelMatrix = glm::translate(m_ModelMatrix, glm::vec3(16.f, 12.f, 0.0));
}

Model::~Model()
{
	UnBind();
	delete m_VB;
	delete m_VBL;
	delete m_IB;
	delete m_Texture;
	delete m_VA;
}

void Model::Bind() const
{
	m_VA->Bind();
	m_IB->Bind();
	m_Texture->Bind();
}

void Model::UnBind() const
{
	m_VA->UnBind();
	m_IB->UnBind();
	m_Texture->UnBind();
}

std::vector<float> Model::ReadObj(const std::string& path_to_obj)
{
	std::vector<float> position_texture_normal;

	std::vector<float> position_vector;
	std::vector<float> normal_vector;
	std::vector<float> texture_coord;

	std::fstream obj;
	std::string input;
	std::vector<std::string> split;
	obj.open(path_to_obj);
	if (obj.is_open())
	{
		while (getline(obj, input))
		{
			split = SplitString(input, ' ');
			int sz = split.size();
			// empty line
			if (sz == 0)
				continue;
			if (split[0] == "v")
			{				
				position_vector.push_back(GetFloat(split[1]));
				position_vector.push_back(GetFloat(split[2]));
				position_vector.push_back(GetFloat(split[3]));
			}
			else if (split[0] == "vt")
			{
				texture_coord.push_back(GetFloat(split[1]));
				texture_coord.push_back(GetFloat(split[2]));
			}
			else if (split[0] == "vn")
			{
				normal_vector.push_back(GetFloat(split[1]));
				normal_vector.push_back(GetFloat(split[2]));
				normal_vector.push_back(GetFloat(split[3]));
			}
			else if (split[0] == "f")
			{
				std::vector<std::string> inSplit;
				for (int i = 1; i <= 3; i++)
				{
					inSplit = SplitString(split[i], '/');
					int index = 3 * (GetInt(inSplit[0]) - 1);

					position_texture_normal.push_back(position_vector[index]);
					position_texture_normal.push_back(position_vector[index + 1]);
					position_texture_normal.push_back(position_vector[index + 2]);

					index = 2 * (GetInt(inSplit[1]) - 1);
					position_texture_normal.push_back(texture_coord[index]);
					position_texture_normal.push_back(texture_coord[index + 1]);

					index = 3 * (GetInt(inSplit[2]) - 1);
					position_texture_normal.push_back(normal_vector[index]);
					position_texture_normal.push_back(normal_vector[index + 1]);
					position_texture_normal.push_back(normal_vector[index + 2]);
				}
				/*for (int i = 2; i <= 4; i++)
				{
					inSplit = SplitString(split[i], '/');
					int index = 3 * (GetInt(inSplit[0]) - 1);

					position_texture_normal.push_back(position_vector[index]);
					position_texture_normal.push_back(position_vector[index + 1]);
					position_texture_normal.push_back(position_vector[index + 2]);

					index = 2 * (GetInt(inSplit[1]) - 1);
					position_texture_normal.push_back(texture_coord[index]);
					position_texture_normal.push_back(texture_coord[index + 1]);

					index = 3 * (GetInt(inSplit[2]) - 1);
					position_texture_normal.push_back(normal_vector[index]);
					position_texture_normal.push_back(normal_vector[index + 1]);
					position_texture_normal.push_back(normal_vector[index + 2]);
				}*/
			}
		}
	}

	return position_texture_normal;
}

std::vector<std::string> Model::SplitString(const std::string& str, char delimiter)
{
	std::vector<std::string> split;
	int sz = str.length(), lastIdx = -1, i;

	for (i = 0; i < sz; i++)
	{
		if (str[i] == delimiter)
		{
			auto temp = str.substr(lastIdx + 1, i - lastIdx - 1);
			if (temp != "")
				split.push_back(temp);
			lastIdx = i;
		}
	}
	if (i == sz && lastIdx != i - 1) split.push_back(str.substr(lastIdx + 1));

	return split;
}

float Model::GetFloat(const std::string& input)
{
	std::istringstream ssinput(input);
	float check;

	ssinput >> check;
	return check;
}

int Model::GetInt(const std::string& input)
{
	std::istringstream ssinput(input);
	int check;

	ssinput >> check;
	return check;
}