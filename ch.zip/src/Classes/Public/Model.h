#pragma once

#include "VertexArray.h"
#include "VertexBuffer.h"
#include "IndexBuffer.h"
#include "Texture.h"

class Model
{
private:

	VertexArray* m_VA;
	VertexBufferLayout* m_VBL;
	VertexBuffer* m_VB;
	IndexBuffer* m_IB;
	Texture* m_Texture;


	std::vector<float> ReadObj(const std::string&);
	std::vector<std::string> SplitString(const std::string&, char delimieter);
	float GetFloat(const std::string&);
	int GetInt(const std::string&);

public:

	glm::mat4 m_ModelMatrix = glm::mat4(1.f);

	Model(const std::string& path_to_obj, const std::string& path_to_png);
	~Model();

	void Bind() const;
	void UnBind() const;

	uint GetIndexCount() const { return m_IB->GetCount(); };

};

