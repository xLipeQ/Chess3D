
typedef unsigned int uint;
typedef unsigned char uchar;